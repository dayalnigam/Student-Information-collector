package com.example.student_information_collector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button Submit,Show;
    EditText Name, Faculty, Rollno;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Submit = (Button) findViewById(R.id.Sbutton);
        Show = (Button) findViewById(R.id.Sbtn);
        Name = (EditText) findViewById(R.id.eName);
        Faculty = (EditText) findViewById(R.id.eFaculty);
        Rollno = (EditText) findViewById(R.id.ERoll);

        final Spinner spinner = (Spinner) findViewById(R.id.gSpin);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.gender, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        final Spinner dspin = (Spinner) findViewById(R.id.gSpine);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.department, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dspin.setAdapter(adapter2);

        openHelper = new DatabaseHelper(this);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = Name.getText().toString();
                String faculty = Faculty.getText().toString();
                String gender = spinner.getSelectedItem().toString();
                String department = dspin.getSelectedItem().toString();
                String rollno = Rollno.getText().toString();
                db = openHelper.getWritableDatabase();
                if(TextUtils.isEmpty(name)){
                    Name.setError("Name is Required.");
                    return;
                }
                if(TextUtils.isEmpty(faculty)){
                    Faculty.setError("Faculty is Required.");
                    return;
                }

                if(TextUtils.isEmpty(rollno)){
                    Rollno.setError("Rollno is Required.");
                    return;
                }
                else if(rollno.length()>=8){
                    Toast.makeText(getApplicationContext(), "your rollno is more than 8 words", Toast.LENGTH_LONG).show();

                }


                else{
                    insertData(name, faculty, gender, department, rollno);
                    Toast.makeText(getApplicationContext(), "INSERTED SUCCESSFULLY", Toast.LENGTH_LONG).show();
                }

            }
        });
        Show.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                SQLiteDatabase db=getApplicationContext().openOrCreateDatabase("STUDENT.db", Context.MODE_PRIVATE,null);
                Cursor c=db.rawQuery("SELECT * FROM student_info ",null);
                if(c.getCount()==0){
                    Toast.makeText(getApplicationContext(),"No record found",Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(c.moveToNext()){
                    buffer.append("Name:"+c.getString(0)+"\n");
                    buffer.append("Faculty:"+c.getString(1)+"\n");
                    buffer.append("Gender:"+c.getString(2)+"\n");
                    buffer.append("Department:"+c.getString(3)+"\n");
                    buffer.append("Roll No: "+c.getString(4)+"\n");
                }
                //Toast.makeText(getApplicationContext(),"All record found :\n"+buffer.toString(),Toast.LENGTH_LONG).show();
                String str = buffer.toString();
                Intent intent = new Intent(getApplicationContext(), ViewData.class);
                intent.putExtra("message_key", str);
                startActivity(intent);
            }
        });



    }

    private void insertData(String name, String faculty, String gender, String department, String rollno) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COLS_1, name);
        contentValues.put(DatabaseHelper.COLS_2, faculty);
        contentValues.put(DatabaseHelper.COLS_3, gender);
        contentValues.put(DatabaseHelper.COLS_4, department);
        contentValues.put(DatabaseHelper.COLS_5, rollno);
        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }
}